# School-management-
C# project
